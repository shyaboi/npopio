var x = document.getElementById("myAudio");


function playAudio() {
  event.preventDefault();
  x.play();
}

