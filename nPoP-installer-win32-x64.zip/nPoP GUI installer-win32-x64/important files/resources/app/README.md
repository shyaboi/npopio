# nPoP Installeer
This in a quick executable GUI installer for the npx nPoP package